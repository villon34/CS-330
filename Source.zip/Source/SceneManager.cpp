///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//  Modified: Added lighting implementation for assignment requirements
//  Modified: Added keyboard to the left of mouse
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.tag = "wood";
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3f;
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.tag = "plastic";
	plasticMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	plasticMaterial.ambientStrength = 0.3f;
	plasticMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	plasticMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	plasticMaterial.shininess = 32.0f;
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.tag = "rubber";
	rubberMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	rubberMaterial.ambientStrength = 0.2f;
	rubberMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	rubberMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	rubberMaterial.shininess = 2.0f;
	m_objectMaterials.push_back(rubberMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.tag = "metal";
	metalMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	metalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(metalMaterial);

	std::cout << "Defined materials: wood, plastic, rubber, metal" << std::endl;
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	//std::cout << "Setting up scene lights..." << std::endl;

	//// Check if shader manager exists
	//if (m_pShaderManager == NULL)
	//{
	//	return;
	//}

	//// Enable lighting in the shader
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	///*** PRIMARY LIGHT SOURCE - Directional Light ***/
	//// Simulates overhead lighting like ceiling lights or sun
	//m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.2f, -1.0f, -0.3f));
	//m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.5f, 0.5f, 0.5f));
	//m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(1.0f, 1.0f, 1.0f));
	//m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.8f, 0.8f, 0.8f));
	//m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	///*** SECONDARY LIGHT SOURCE - Point Light ***/
	//// Provides fill lighting to eliminate shadows
	//m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(10.0f, 8.0f, 5.0f));
	//m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.3f, 0.3f, 0.3f));
	//m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.8f, 0.8f, 0.8f));
	//m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.6f, 0.6f, 0.6f));
	//m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	//// Attenuation values for realistic falloff
	//m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
	//m_pShaderManager->setFloatValue("pointLights[0].linear", 0.045f);
	//m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.0075f);

	///*** TERTIARY LIGHT SOURCE - Point Light ***/
	//// Additional fill light from opposite side
	//m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(2.0f, 6.0f, 8.0f));
	//m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.25f, 0.25f, 0.25f));
	//m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.7f, 0.7f, 0.7f));
	//m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.5f, 0.5f, 0.5f));
	//m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	//// Attenuation values - reduced for wider light spread
	//m_pShaderManager->setFloatValue("pointLights[1].constant", 1.0f);
	//m_pShaderManager->setFloatValue("pointLights[1].linear", 0.045f);
	//m_pShaderManager->setFloatValue("pointLights[1].quadratic", 0.0075f);

	//std::cout << "Scene lights configured successfully!" << std::endl;
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading all textures needed for
 *  the 3D scene. After loading, BindGLTextures() is called
 *  to bind them to OpenGL texture slots.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	std::cout << "Loading scene textures..." << std::endl;

	// Desk surface texture
	if (CreateGLTexture("textures/wood_desk2.jpg", "desk")) {
		std::cout << "SUCCESS: Loaded desk texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/wood_desk2.jpg" << std::endl;
	}

	// Mouse body and buttons texture - shared plastic texture
	if (CreateGLTexture("textures/mouse_plastic.jpg", "mouse_main")) {
		std::cout << "SUCCESS: Loaded mouse main texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/mouse_plastic.jpg" << std::endl;
	}

	// Scroll wheel texture - rubber or textured surface
	if (CreateGLTexture("textures/rubber_texture.jpg", "scroll_wheel")) {
		std::cout << "SUCCESS: Loaded scroll wheel texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/rubber_texture.jpg" << std::endl;
	}

	// Keyboard texture - plastic keys
	if (CreateGLTexture("textures/black.jpg", "keyboard")) {
		std::cout << "SUCCESS: Loaded keyboard texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/black.jpg" << std::endl;
	}

	// Monitor screen texture - black screen
	if (CreateGLTexture("textures/black.jpg", "monitor_screen")) {
		std::cout << "SUCCESS: Loaded monitor screen texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/black.jpg" << std::endl;
	}

	// Monitor stand texture - metal/plastic
	if (CreateGLTexture("textures/iron.jpg", "monitor_stand")) {
		std::cout << "SUCCESS: Loaded monitor stand texture!" << std::endl;
	}
	else {
		std::cout << "FAILED: Could not load textures/iron.jpg" << std::endl;
	}

	std::cout << "Total textures loaded: " << m_loadedTextures << std::endl;

	// Bind all loaded textures to OpenGL texture slots
	BindGLTextures();
	std::cout << "All textures bound to OpenGL slots." << std::endl;
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load all necessary meshes for the computer mouse and keyboard
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();     // For mouse body
	m_basicMeshes->LoadBoxMesh();        // For mouse buttons and keyboard
	m_basicMeshes->LoadCylinderMesh();   // For scroll wheel

	// Define material properties for all objects
	// Must be called before rendering to apply Phong lighting
	DefineObjectMaterials();

	// Load and bind all scene textures
	LoadSceneTextures();

	// Setup scene lights (only once during initialization)
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** TEXTURED AND LIT GROUND PLANE ***/
	// The plane reflects light using wood material properties
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply wood material for proper light reflection
	SetShaderMaterial("wood");

	// Apply desk texture with tiling
	SetShaderTexture("desk");
	SetTextureUVScale(4.0f, 2.0f);

	m_basicMeshes->DrawPlaneMesh();

	/*** KEYBOARD BASE ***/
	// Main keyboard body positioned to the left of the mouse, rotated 180 degrees
	scaleXYZ = glm::vec3(4.5f, 0.3f, 1.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 180.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.15f, 0.3f, 3.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material
	SetShaderMaterial("plastic");

	// Apply keyboard texture
	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** KEYBOARD KEYS - Top Row ***/
	// Create individual keys for realistic appearance (rotated 180 degrees)
	float keyWidth = 0.25f;
	float keyHeight = 0.15f;
	float keyDepth = 0.25f;
	float keySpacing = 0.3f;
	float startX = 1.25f;  // Starting from right side now
	float keyY = 0.50f;
	float keyZ = 2.4f;  // Keys closer to user (lower Z)

	// Top row of keys (approximate 10 keys) - now arranged right to left
	for (int i = 0; i < 10; i++)
	{
		scaleXYZ = glm::vec3(keyWidth, keyHeight, keyDepth);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 180.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(startX - (i * keySpacing), keyY, keyZ);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

		SetShaderMaterial("plastic");
		SetShaderTexture("keyboard");
		SetTextureUVScale(1.0f, 1.0f);

		m_basicMeshes->DrawBoxMesh();
	}

	/*** KEYBOARD KEYS - Middle Row ***/
	float middleRowZ = 2.8f;
	for (int i = 0; i < 10; i++)
	{
		scaleXYZ = glm::vec3(keyWidth, keyHeight, keyDepth);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 180.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(startX - (i * keySpacing), keyY, middleRowZ);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

		SetShaderMaterial("plastic");
		SetShaderTexture("keyboard");
		SetTextureUVScale(1.0f, 1.0f);

		m_basicMeshes->DrawBoxMesh();
	}

	/*** KEYBOARD KEYS - Bottom Row ***/
	float bottomRowZ = 3.2f;
	for (int i = 0; i < 10; i++)
	{
		scaleXYZ = glm::vec3(keyWidth, keyHeight, keyDepth);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 180.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(startX - (i * keySpacing), keyY, bottomRowZ);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

		SetShaderMaterial("plastic");
		SetShaderTexture("keyboard");
		SetTextureUVScale(1.0f, 1.0f);

		m_basicMeshes->DrawBoxMesh();
	}

	/*** KEYBOARD SPACEBAR ***/
	scaleXYZ = glm::vec3(2.0f, 0.15f, 0.25f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 180.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.15f, 0.50f, 3.6f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** MONITOR STAND BASE ***/
	// Square base positioned north of the keyboard (behind it since keyboard is rotated 180)
	scaleXYZ = glm::vec3(3.0f, 0.2f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.5f, 0.2f, 0.5f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("metal");
	SetShaderTexture("monitor_stand");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** MONITOR STAND ARM ***/
	// Vertical rectangle connecting base to monitor
	scaleXYZ = glm::vec3(1.0f, 1.5f, 0.1f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.5f, 1.0f, -0.25f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("metal");
	SetShaderTexture("monitor_stand");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** MONITOR SCREEN ***/
	// Black rectangular monitor screen
	scaleXYZ = glm::vec3(10.0f, 5.0f, 0.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.5f, 4.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderTexture("monitor_screen");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** MOUSEPAD ***/
	// Thin rectangular pad under the mouse
	scaleXYZ = glm::vec3(3.0f, 0.05f, 3.5f);  // Slightly larger mousepad
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.5f, 0.05f, 3.0f);  // Moved left near keyboard

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply rubber material for mousepad
	SetShaderMaterial("rubber");

	// Apply desk texture for simple appearance (or create a custom mousepad texture)
	SetShaderTexture("desk");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** TEXTURED AND LIT MOUSE BODY ***/
	// Main component with plastic material
	scaleXYZ = glm::vec3(0.6f, 0.32f, 0.96f);  // 40% of original (1.5, 0.8, 2.4)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.5f, 0.38f, 3.0f);  // Moved left, sits on mousepad

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material for realistic appearance
	SetShaderMaterial("plastic");

	// Apply mouse texture
	SetShaderTexture("mouse_main");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawSphereMesh();

	/*** TEXTURED AND LIT MOUSE LEFT BUTTON ***/
	// Uses same texture and material as body for cohesion - scaled to 40%
	scaleXYZ = glm::vec3(0.24f, 0.08f, 0.44f);  // 40% of original (0.6, 0.2, 1.1)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.18f, 0.76f, 3.12f);  // Adjusted for 40% scale

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material
	SetShaderMaterial("plastic");

	// Apply mouse texture
	SetShaderTexture("mouse_main");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** TEXTURED AND LIT MOUSE RIGHT BUTTON ***/
	// Identical to left button for symmetry - scaled to 40%
	scaleXYZ = glm::vec3(0.24f, 0.08f, 0.44f);  // 40% of original (0.6, 0.2, 1.1)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.5f, 0.76f, 3.12f);  // Adjusted for 40% scale

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material
	SetShaderMaterial("plastic");

	// Apply mouse texture
	SetShaderTexture("mouse_main");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/*** TEXTURED AND LIT SCROLL WHEEL ***/
	// Different texture and material for contrast - scaled to 40%
	scaleXYZ = glm::vec3(0.08f, 0.3f, 0.08f);  // 40% of original (0.2, 0.25, 0.2)
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.34f, 0.78f, 3.00);  // Adjusted for 40% scale

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply rubber material for matte appearance
	SetShaderMaterial("rubber");

	// Apply rubber texture with enhanced detail
	SetShaderTexture("scroll_wheel");
	SetTextureUVScale(2.0f, 2.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Reset UV scale back to default for subsequent objects
	SetTextureUVScale(1.0f, 1.0f);

	/*** COFFEE MUG ***/
	// Position to the right of the monitor on the desk

	// Mug body - cylinder
	scaleXYZ = glm::vec3(0.8f, 1.2f, 0.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(7.0f, 0.6f, 2.0f);  // To the right of monitor

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material for ceramic appearance
	SetShaderMaterial("plastic");

	// Set blue color for the mug (RGB: 0.2, 0.4, 0.8 for a nice blue)
	SetShaderColor(0.2f, 0.4f, 0.8f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Mug handle - created using three cylinders to form a C-shape
	// Vertical part 1 (top)
	scaleXYZ = glm::vec3(0.15f, 0.5f, 0.15f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(7.7f, 0.8f, 2.0f);  // Right side of mug, upper part

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material
	SetShaderMaterial("plastic");

	// Set blue color for the handle to match the mug
	SetShaderColor(0.2f, 0.4f, 0.8f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Curved part (middle) - rotated cylinder
	scaleXYZ = glm::vec3(0.15f, 0.6f, 0.15f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;  // Rotate to be horizontal
	positionXYZ = glm::vec3(7.7f, 0.6f, 2.0f);  // Middle part

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderColor(0.2f, 0.4f, 0.8f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Vertical part 2 (bottom)
	scaleXYZ = glm::vec3(0.15f, 0.5f, 0.15f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(7.7f, 0.4f, 2.0f);  // Right side of mug, lower part

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderColor(0.2f, 0.4f, 0.8f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/*** DESK LAMP - To the left of the monitor ***/

	// LAMP BASE - Wide short cylinder
	scaleXYZ = glm::vec3(1.2f, 0.2f, 1.2f);  // Wide and short
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.0f, 0.1f, 0.0f);  // To the left of the monitor

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply metal material for the base
	SetShaderMaterial("metal");
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);  // Dark gray metal color

	m_basicMeshes->DrawCylinderMesh();

	// VERTICAL ARM - Long skinny cylinder standing on base
	scaleXYZ = glm::vec3(0.15f, 7.0f, 0.15f);  // Skinny and tall
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.0f, 0.0f, 0.0f);  // Centered on base, extends upward

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("metal");
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);  // Same dark gray

	m_basicMeshes->DrawCylinderMesh();

	// DIAGONAL ARM - Long skinny cylinder at angle
	scaleXYZ = glm::vec3(0.15f, 5.0f, 0.15f);  // Skinny and long
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -45.0f;  // 45-degree angle pointing toward monitor
	positionXYZ = glm::vec3(-5.0f, 7.0f, 0.0f);  // Connected to top of vertical arm, angled toward monitor

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("metal");
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// LAMP SHADE - Cone shape
	scaleXYZ = glm::vec3(1.8f, 1.6f, 1.8f);
	XrotationDegrees = 180.0f;  // Flip cone upside down for lamp shade
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.0f, 9.8f, 1.5f);  // At end of diagonal arm, above monitor

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("metal");
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);  // Darker shade

	m_basicMeshes->DrawConeMesh();

	// LIGHT BULB - Small sphere inside shade
	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.3f, 10.5f, 0.0f);  // Inside the lamp shade

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderColor(1.0f, 1.0f, 0.8f, 1.0f);  // Warm white/yellow for light bulb

	m_basicMeshes->DrawSphereMesh();

	/*** BOOKS - Stacked to the right of the coffee mug ***/

	// BOTTOM BOOK - Green
	scaleXYZ = glm::vec3(3.6f, 0.9f, 4.8f);  // Book dimensions: width, height (spine), depth - 3x larger
	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f;  // Slight rotation for a more natural look
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(11.0f, 0.45f, 1.5f);  // To the right of the coffee mug, on desk - adjusted height

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material for book cover
	SetShaderMaterial("plastic");

	// Set green color for the bottom book
	SetShaderColor(0.2f, 0.7f, 0.2f, 1.0f);  // Green color

	m_basicMeshes->DrawBoxMesh();

	// TOP BOOK - Red
	scaleXYZ = glm::vec3(3.0f, 0.75f, 4.2f);  // Slightly smaller book on top - 3x larger
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;  // Rotated opposite direction for visual interest
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(11.0f, 1.65f, 1.5f);  // Stacked on top of bottom book - adjusted height

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply plastic material for book cover
	SetShaderMaterial("plastic");

	// Set red color for the top book
	SetShaderColor(0.8f, 0.1f, 0.1f, 1.0f);  // Red color

	m_basicMeshes->DrawBoxMesh();
}